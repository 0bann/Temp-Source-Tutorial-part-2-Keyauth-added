﻿using ConsoleApp2;
using KeyAuth;
using static System.Net.Mime.MediaTypeNames;
using System.Diagnostics;
using System.Net;


namespace spoof
{
    static class Program
    {

        public static api KeyAuthApp = new api(
      name: "", // Application Name
    ownerid: "", // Owner ID
    secret: "", // Application Secret
    version: ""
  );

        public static void Main()
        {

            Console.Title = "Loader";
            Console.WriteLine("\n\n Connecting..");
            KeyAuthApp.init();
            autoUpdate();

            Console.Clear();
            login();


            Console.Clear();
            Console.Title = "Spoofer Tutorial";
            menu();
           


            static void login()
            {
                string key;
                try
                {
                    Console.Write("\n\n Enter license: ");
                    key = Console.ReadLine();
                    KeyAuthApp.license(key);

                    if (!KeyAuthApp.response.success)
                    {
                        Console.WriteLine("\n Status: " + KeyAuthApp.response.message);
                        Thread.Sleep(2500);
                        Environment.Exit(0);
                    }
                }
                catch (Exception e)
                {

                }

            }


            static void autoUpdate()
            {
                if (KeyAuthApp.response.message == "invalidver")
                {


                    Process.Start(KeyAuthApp.app_data.downloadLink);
                    Environment.Exit(0);


                    WebClient webClient = new WebClient();
                    string executablePath = Process.GetCurrentProcess().MainModule.FileName;

                    string rand = random_string();
                    string destFile = executablePath.Replace(".exe", $"-{rand}.exe");
                    webClient.DownloadFile(KeyAuthApp.app_data.downloadLink, destFile);

                    Process.Start(destFile);
                    ProcessStartInfo processStartInfo = new ProcessStartInfo
                    {
                        FileName = "cmd.exe",
                        Arguments = $"/C choice /C Y /N /D Y /T 3 & Del \"{executablePath}\"",
                        WindowStyle = ProcessWindowStyle.Hidden,
                        CreateNoWindow = true
                    };
                    Process.Start(processStartInfo);

                    Environment.Exit(0);
                }

                      
           
                
            }

            static string random_string()
            {
                string str = null;

                Random random = new Random();
                for (int i = 0; i < 5; i++)
                {
                    str += Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65))).ToString();
                }
                return str;
            }









        }

        public static void menu()
        {

            Console.Clear();
            Console.Write("\n[1] Spoof\n\n[2] Check Serials\n\n[3] Clean Traces\n\n\nEnter Your Choice:");


            int choice;
            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        Console.Clear();
                        Spoof.Temp();
                        Thread.Sleep(3000);
                        Spoof.Mac();
                        Thread.Sleep(8000);
                        Console.WriteLine("Done Spoofing!");
                        break;

                    case 2:
                        Console.Clear();
                        Spoof.Serials();
                        break;

                    case 3:
                        Console.Clear();
                        Spoof.Clean();
                        Thread.Sleep(1000);
                        Console.WriteLine("Done Cleaning Traces");
                        break;

                    default:
                        Console.WriteLine("Invalid Choice. Please enter a valid option");
                        break;


                }

            }
        }




    }




}