﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;
using System.Net;
using spoof;
using System.Diagnostics;
using System.Net.NetworkInformation;


namespace ConsoleApp2
{
    internal class Spoof
    {

        public static void Temp()
        {
            string map = @"C:\Windows\IME\Mapper.exe";
            string sys = @"C:\Windows\IME\Spoofdriver.sys";

            using (WebClient webClient = new WebClient())
            {
                webClient.DownloadFile("ADD DOWNLOAD LINK HERE", map);
                webClient.DownloadFile("ADD DOWNLOAD LINK HERE", sys);
            }

            Process process = new Process();
            process.StartInfo.FileName = map;
            process.StartInfo.Arguments = sys;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            process.Start();
            process.WaitForExit();
            File.Delete(map);
            File.Delete(sys);
        }

        public static void Mac()
        {
            string mac = @"C:\Windows\IME\Mapper.exe";


            using (WebClient webClient = new WebClient())
            {
                webClient.DownloadFile("ADD DOWNLOAD LINK HERE", mac);
         
            }

            Process process = new Process();
            process.StartInfo.FileName = mac;
            process.StartInfo.Arguments = "";
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            process.Start();
            process.WaitForExit();
            File.Delete(mac);
            Thread.Sleep(6000);
            Program.menu();

        }


        public static void Serials()
        {
            Console.WriteLine("Disk Drives");
            var diskSearcher = new ManagementObjectSearcher("Select * FROM Win32_DiskDrive");
            foreach (ManagementObject drive in diskSearcher.Get())
            {
                Console.WriteLine($"Model: {drive["Model"]}");
                Console.WriteLine($"Serial Number: {drive["SerialNumber"]}");
            }

            Console.WriteLine("\nCPU:");
            var cpuSearcher = new ManagementObjectSearcher("Select * FROM Win32_Processor");
            foreach (ManagementObject bios in cpuSearcher.Get())
            {
              
                Console.WriteLine($"Serial Number: {bios["SerialNumber"]}");
            }


            Console.WriteLine("\nMotherboard:");
            var mbSearcher = new ManagementObjectSearcher("Select * FROM Win32_BaseBoard");
            foreach (ManagementObject motherboard in mbSearcher.Get())
            {

                Console.WriteLine($"Serial Number: {motherboard["SerialNumber"]}");
            }


            Console.WriteLine("\nBIOS:");
            var biosSearcher = new ManagementObjectSearcher("Select * FROM Win32_BIOS");
            foreach (ManagementObject bios in biosSearcher.Get())
            {

                Console.WriteLine($"Serial Number: {bios["SerialNumber"]}");
            }

            Console.WriteLine("\nMAC Address:");
            foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                var macAddress = nic.GetPhysicalAddress();
                if (macAddress != null && macAddress.ToString() != string.Empty) ;
                {
                    Console.WriteLine($"MAC Address: {macAddress}");
                }
               
            }

            Console.WriteLine("\n\nEnter Any Key to Return to Menu");
            Console.ReadKey();
            Program.menu();

        }

        public static void Clean()
        {

        }
    }
}
